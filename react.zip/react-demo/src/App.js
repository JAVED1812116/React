//import logo from './logo.svg';
import './App.css';
import CourseList from './components/CourseList';
//import UserForm from './components/UserForm';

function App() {
	return (
		<div className='App'>
			{/* <UserForm /> */}
			<CourseList />
		</div>
	);
}

export default App;
